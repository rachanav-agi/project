import { createacc } from './createacc';

describe('Createacc', () => {
  it('should create an instance', () => {
    expect(new createacc()).toBeTruthy();
  });
});
