import { Userdetails } from './userdetails';

describe('Userdetails', () => {
  it('should create an instance', () => {
    expect(new Userdetails()).toBeTruthy();
  });
});
